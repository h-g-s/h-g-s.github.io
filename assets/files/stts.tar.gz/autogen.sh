#!/bin/sh
autoreconf
aclocal
autoheader
automake -a -c --foreign
autoconf


  <SolutionGroup Id="GOAL team Fri Dec  6 16:52:53 2013
">
    <MetaData>
      <Contributor>GOAL team: Fonseca, G.H.G., Brito, S., Toffolo, T. and Santos, H.G.</Contributor>
      <Date>Fri Dec  6 16:52:53 2013
</Date>
      <Description>Hibrid heuristic and IP methods</Description>
      <Remarks>Under development (Random seed = 1)</Remarks>
    </MetaData>
    <Solution Reference="BR-SA-00">
      <Events>
        <Event Reference="T1-S1">
          <Duration>2</Duration>
          <Time Reference="Tu_1"/>
        </Event>
        <Event Reference="T1-S1">
          <Duration>2</Duration>
          <Time Reference="Th_1"/>
        </Event>
        <Event Reference="T1-S2">
          <Duration>1</Duration>
          <Time Reference="We_5"/>
        </Event>
        <Event Reference="T1-S2">
          <Duration>2</Duration>
          <Time Reference="Th_3"/>
        </Event>
        <Event Reference="T1-S3">
          <Duration>2</Duration>
          <Time Reference="Tu_3"/>
        </Event>
        <Event Reference="T1-S3">
          <Duration>2</Duration>
          <Time Reference="Fr_2"/>
        </Event>
        <Event Reference="T2-S2">
          <Time Reference="Mo_1"/>
        </Event>
        <Event Reference="T2-S4">
          <Duration>1</Duration>
          <Time Reference="Tu_5"/>
        </Event>
        <Event Reference="T2-S4">
          <Duration>2</Duration>
          <Time Reference="Th_1"/>
        </Event>
        <Event Reference="T2-S5">
          <Duration>2</Duration>
          <Time Reference="Mo_3"/>
        </Event>
        <Event Reference="T2-S5">
          <Duration>1</Duration>
          <Time Reference="Th_5"/>
        </Event>
        <Event Reference="T2-S6">
          <Duration>2</Duration>
          <Time Reference="Tu_3"/>
        </Event>
        <Event Reference="T2-S6">
          <Duration>2</Duration>
          <Time Reference="Th_3"/>
        </Event>
        <Event Reference="T3-S4">
          <Time Reference="Mo_5"/>
        </Event>
        <Event Reference="T3-S5">
          <Time Reference="We_4"/>
        </Event>
        <Event Reference="T3-S6">
          <Time Reference="We_5"/>
        </Event>
        <Event Reference="T4-S1">
          <Duration>2</Duration>
          <Time Reference="Mo_3"/>
        </Event>
        <Event Reference="T4-S1">
          <Duration>1</Duration>
          <Time Reference="We_5"/>
        </Event>
        <Event Reference="T4-S2">
          <Duration>1</Duration>
          <Time Reference="Mo_2"/>
        </Event>
        <Event Reference="T4-S2">
          <Duration>2</Duration>
          <Time Reference="We_3"/>
        </Event>
        <Event Reference="T4-S3">
          <Duration>1</Duration>
          <Time Reference="Mo_5"/>
        </Event>
        <Event Reference="T4-S3">
          <Duration>2</Duration>
          <Time Reference="We_1"/>
        </Event>
        <Event Reference="T4-S4">
          <Duration>2</Duration>
          <Time Reference="Tu_1"/>
        </Event>
        <Event Reference="T4-S4">
          <Duration>1</Duration>
          <Time Reference="Th_5"/>
        </Event>
        <Event Reference="T5-S5">
          <Duration>1</Duration>
          <Time Reference="We_5"/>
        </Event>
        <Event Reference="T5-S5">
          <Duration>2</Duration>
          <Time Reference="Th_3"/>
        </Event>
        <Event Reference="T5-S6">
          <Duration>2</Duration>
          <Time Reference="Tu_1"/>
        </Event>
        <Event Reference="T5-S6">
          <Duration>2</Duration>
          <Time Reference="Th_1"/>
        </Event>
        <Event Reference="T6-S1">
          <Duration>2</Duration>
          <Time Reference="Mo_1"/>
        </Event>
        <Event Reference="T6-S1">
          <Duration>1</Duration>
          <Time Reference="Th_5"/>
        </Event>
        <Event Reference="T6-S2">
          <Duration>1</Duration>
          <Time Reference="Mo_5"/>
        </Event>
        <Event Reference="T6-S2">
          <Duration>2</Duration>
          <Time Reference="Tu_3"/>
        </Event>
        <Event Reference="T6-S3">
          <Duration>2</Duration>
          <Time Reference="Mo_3"/>
        </Event>
        <Event Reference="T6-S3">
          <Duration>1</Duration>
          <Time Reference="We_5"/>
        </Event>
        <Event Reference="T6-S4">
          <Duration>1</Duration>
          <Time Reference="We_4"/>
        </Event>
        <Event Reference="T6-S4">
          <Duration>2</Duration>
          <Time Reference="Fr_2"/>
        </Event>
        <Event Reference="T6-S5">
          <Duration>2</Duration>
          <Time Reference="We_2"/>
        </Event>
        <Event Reference="T6-S5">
          <Duration>1</Duration>
          <Time Reference="Fr_1"/>
        </Event>
        <Event Reference="T6-S6">
          <Duration>1</Duration>
          <Time Reference="Tu_5"/>
        </Event>
        <Event Reference="T6-S6">
          <Duration>2</Duration>
          <Time Reference="Fr_4"/>
        </Event>
        <Event Reference="T7-S1">
          <Duration>1</Duration>
          <Time Reference="Tu_5"/>
        </Event>
        <Event Reference="T7-S1">
          <Duration>2</Duration>
          <Time Reference="Fr_4"/>
        </Event>
        <Event Reference="T7-S2">
          <Duration>2</Duration>
          <Time Reference="Mo_3"/>
        </Event>
        <Event Reference="T7-S2">
          <Duration>1</Duration>
          <Time Reference="Fr_1"/>
        </Event>
        <Event Reference="T7-S3">
          <Duration>2</Duration>
          <Time Reference="Mo_1"/>
        </Event>
        <Event Reference="T7-S3">
          <Duration>1</Duration>
          <Time Reference="Th_5"/>
        </Event>
        <Event Reference="T7-S4">
          <Duration>2</Duration>
          <Time Reference="Tu_3"/>
        </Event>
        <Event Reference="T7-S4">
          <Duration>1</Duration>
          <Time Reference="We_3"/>
        </Event>
        <Event Reference="T7-S5">
          <Duration>2</Duration>
          <Time Reference="Tu_1"/>
        </Event>
        <Event Reference="T7-S5">
          <Duration>1</Duration>
          <Time Reference="We_1"/>
        </Event>
        <Event Reference="T7-S6">
          <Duration>1</Duration>
          <Time Reference="Mo_5"/>
        </Event>
        <Event Reference="T7-S6">
          <Duration>2</Duration>
          <Time Reference="Fr_2"/>
        </Event>
        <Event Reference="T8-S1">
          <Duration>1</Duration>
          <Time Reference="Mo_5"/>
        </Event>
        <Event Reference="T8-S1">
          <Duration>2</Duration>
          <Time Reference="We_1"/>
        </Event>
        <Event Reference="T8-S2">
          <Duration>1</Duration>
          <Time Reference="Th_5"/>
        </Event>
        <Event Reference="T8-S2">
          <Duration>2</Duration>
          <Time Reference="Fr_2"/>
        </Event>
        <Event Reference="T8-S3">
          <Duration>2</Duration>
          <Time Reference="We_3"/>
        </Event>
        <Event Reference="T8-S3">
          <Duration>1</Duration>
          <Time Reference="Fr_1"/>
        </Event>
        <Event Reference="T8-S4">
          <Duration>1</Duration>
          <Time Reference="We_5"/>
        </Event>
        <Event Reference="T8-S4">
          <Duration>2</Duration>
          <Time Reference="Fr_4"/>
        </Event>
        <Event Reference="T8-S5">
          <Duration>2</Duration>
          <Time Reference="Mo_1"/>
        </Event>
        <Event Reference="T8-S5">
          <Duration>1</Duration>
          <Time Reference="Th_4"/>
        </Event>
        <Event Reference="T8-S6">
          <Time Reference="Mo_3"/>
        </Event>
        <Event Reference="T9-S4">
          <Time Reference="We_1"/>
        </Event>
        <Event Reference="T9-S6">
          <Time Reference="We_3"/>
        </Event>
        <Event Reference="T10-S1">
          <Time Reference="Th_3"/>
        </Event>
        <Event Reference="T10-S2">
          <Time Reference="Th_1"/>
        </Event>
        <Event Reference="T10-S3">
          <Time Reference="Fr_4"/>
        </Event>
        <Event Reference="T10-S5">
          <Time Reference="Fr_2"/>
        </Event>
        <Event Reference="T11-S1">
          <Time Reference="Fr_2"/>
        </Event>
        <Event Reference="T11-S2">
          <Time Reference="Fr_4"/>
        </Event>
        <Event Reference="T11-S3">
          <Time Reference="Th_3"/>
        </Event>
        <Event Reference="T11-S4">
          <Time Reference="Mo_3"/>
        </Event>
        <Event Reference="T11-S5">
          <Time Reference="Th_1"/>
        </Event>
        <Event Reference="T11-S6">
          <Time Reference="Mo_1"/>
        </Event>
        <Event Reference="T12-S1">
          <Time Reference="We_3"/>
        </Event>
        <Event Reference="T12-S2">
          <Time Reference="We_1"/>
        </Event>
        <Event Reference="T12-S3">
          <Time Reference="Tu_1"/>
        </Event>
        <Event Reference="T12-S4">
          <Time Reference="Mo_1"/>
        </Event>
        <Event Reference="T12-S5">
          <Time Reference="Tu_4"/>
        </Event>
        <Event Reference="T12-S6">
          <Time Reference="Th_4"/>
        </Event>
        <Event Reference="T13-S1">
          <Time Reference="Tu_3"/>
        </Event>
        <Event Reference="T13-S2">
          <Time Reference="Tu_1"/>
        </Event>
        <Event Reference="T13-S3">
          <Time Reference="Th_1"/>
        </Event>
        <Event Reference="T13-S4">
          <Time Reference="Th_3"/>
        </Event>
        <Event Reference="T13-S5">
          <Time Reference="Fr_4"/>
        </Event>
        <Event Reference="T13-S6">
          <Time Reference="We_1"/>
        </Event>
        <Event Reference="T14-S1">
          <Time Reference="Tu_4"/>
        </Event>
        <Event Reference="T14-S2">
          <Time Reference="Tu_5"/>
        </Event>
        <Event Reference="T14-S3">
          <Time Reference="Tu_5"/>
        </Event>
        <Event Reference="T14-S4">
          <Time Reference="Fr_1"/>
        </Event>
        <Event Reference="T14-S5">
          <Time Reference="Tu_3"/>
        </Event>
      </Events>
      <Report>
        <InfeasibilityValue>4</InfeasibilityValue>
        <ObjectiveValue>90</ObjectiveValue>
        <Resources>
          <Resource Reference="T1">
            <Constraint Reference="MaxNofDaysConstraint_T_days_3">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T2">
            <Constraint Reference="noIDLETimesT">
              <Cost>3</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T3">
            <Constraint Reference="MaxNofDaysConstraint_T_days_1">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T4">
            <Constraint Reference="MaxNofDaysConstraint_T_days_3">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T5">
            <Constraint Reference="MaxNofDaysConstraint_T_days_2">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T6">
            <Constraint Reference="MaxNofDaysConstraint_T_days_4">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T7">
            <Constraint Reference="noIDLETimesT">
              <Cost>3</Cost>
            </Constraint>
            <Constraint Reference="MaxNofDaysConstraint_T_days_4">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T12">
            <Constraint Reference="noIDLETimesT">
              <Cost>3</Cost>
            </Constraint>
            <Constraint Reference="MaxNofDaysConstraint_T_days_3">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T13">
            <Constraint Reference="MaxNofDaysConstraint_T_days_3">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="T14">
            <Constraint Reference="NoResourceClashes">
              <Cost>1</Cost>
            </Constraint>
            <Constraint Reference="MaxNofDaysConstraint_T_days_1">
              <Cost>9</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="S1">
            <Constraint Reference="NoResourceClashes">
              <Cost>1</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="S5">
            <Constraint Reference="NoResourceClashes">
              <Cost>1</Cost>
            </Constraint>
          </Resource>
          <Resource Reference="S6">
            <Constraint Reference="NoResourceClashes">
              <Cost>1</Cost>
            </Constraint>
          </Resource>
        </Resources>
      </Report>
    </Solution>
  </SolutionGroup>
